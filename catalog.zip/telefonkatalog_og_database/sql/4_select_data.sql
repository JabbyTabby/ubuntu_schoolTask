SELECT * FROM person;

SELECT fornavn, telefonnummer FROM person;

SELECT * FROM person WHERE fornavn = "Erik";

SELECT telefonnummer FROM person WHERE fornavn = "Lise" AND etternavn = "Pise";

