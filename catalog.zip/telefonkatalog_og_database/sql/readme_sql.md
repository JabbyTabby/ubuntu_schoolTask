I denne katalogen er det fire sql-script.

De kan kjøres ved kopiere koden inn i terminalvinduet til MySQL/MariaDB.

Scriptene må kjøres i rekkefølgen angitt av tallene.