# telefonkatalog_og_database
Python og SQL-kode for telefonkatalog-prosjektet
